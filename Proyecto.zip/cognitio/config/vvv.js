module.exports = {
	'secret': 'jsdalDosa8da1jj',
	'name': 'SSupaSSesionSS'
}
