module.exports = {
	'connectionLimit' : '100',
	'host': 'localhost',
	'port':'3306',
	'user':'root',
	'password':'12345',
	'database':'cognitio'
};
